// server.mjs
import { createServer } from 'node:http';
import {suma, resta, multiplicacion, division} from './calculos.js';

const server = createServer((req, res) => {
  res.writeHead(200, { 'Content-Type': 'text/html' });
  res.end(`
    <h1>Ejercicio 5</h1>
    <p>La suma de 4 y 5 es: ${suma(4, 5)}</p>
    <p>La resta de 3 y 6 es: ${resta(3, 6)}</p>
    <p>La multiplicación de 2 y 7 es: ${multiplicacion(2, 7)}</p>
    <p>La división de 20 y 4 es: ${division(20, 4)}</p>
    <p>Fin</p>
  `);

});

// starts a simple http server locally on port 3000
server.listen(3000, '127.0.0.1', () => {
  console.log('Listening on 127.0.0.1:3000');
});

// run with `node server.mjs`
