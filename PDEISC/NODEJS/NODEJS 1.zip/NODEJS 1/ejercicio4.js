import {suma, resta, multiplicacion, division} from './calculos.js';

console.log(suma(4, 5));
console.log(resta(3, 6));
console.log(multiplicacion(2, 7));
console.log(division(20, 4));
console.log("Fin");