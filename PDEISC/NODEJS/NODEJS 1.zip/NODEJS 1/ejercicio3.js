function suma(a, b) {
    return a + b;
}


function resta(a, b) {
    return a - b;
}

function multiplicación(a, b) {
    return a * b;
}   

function división(a, b) {
    return a / b;
}

console.log(suma(4, 5));
console.log(resta(3, 6));
console.log(multiplicación(2, 7));
console.log(división(20, 4));
console.log("Fin");